﻿namespace ShomoyClub
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin));
            this.panel1 = new System.Windows.Forms.Panel();
            this.dept = new System.Windows.Forms.ComboBox();
            this.w_date = new System.Windows.Forms.DateTimePicker();
            this.d_date = new System.Windows.Forms.DateTimePicker();
            this.b_gr = new System.Windows.Forms.ComboBox();
            this.invalid_members = new System.Windows.Forms.Button();
            this.Add_member = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.member_add = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.requests = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.blood_donor = new System.Windows.Forms.Button();
            this.member_details = new System.Windows.Forms.Button();
            this.expense_details = new System.Windows.Forms.Button();
            this.deposit_details = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.remove = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.rmember_id = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.update = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.p_numb = new System.Windows.Forms.TextBox();
            this.mail = new System.Windows.Forms.TextBox();
            this.s_age = new System.Windows.Forms.TextBox();
            this.sid = new System.Windows.Forms.TextBox();
            this.s_name = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.withdraw = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.w_id = new System.Windows.Forms.TextBox();
            this.w_det = new System.Windows.Forms.TextBox();
            this.re_wam = new System.Windows.Forms.TextBox();
            this.w_am = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.deposit = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.d_det = new System.Windows.Forms.TextBox();
            this.re_am = new System.Windows.Forms.TextBox();
            this.d_am = new System.Windows.Forms.TextBox();
            this.d_id = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Controls.Add(this.dept);
            this.panel1.Controls.Add(this.w_date);
            this.panel1.Controls.Add(this.d_date);
            this.panel1.Controls.Add(this.b_gr);
            this.panel1.Controls.Add(this.invalid_members);
            this.panel1.Controls.Add(this.Add_member);
            this.panel1.Controls.Add(this.label25);
            this.panel1.Controls.Add(this.member_add);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.requests);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label24);
            this.panel1.Controls.Add(this.blood_donor);
            this.panel1.Controls.Add(this.member_details);
            this.panel1.Controls.Add(this.expense_details);
            this.panel1.Controls.Add(this.deposit_details);
            this.panel1.Controls.Add(this.button7);
            this.panel1.Controls.Add(this.remove);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Controls.Add(this.rmember_id);
            this.panel1.Controls.Add(this.label22);
            this.panel1.Controls.Add(this.update);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.p_numb);
            this.panel1.Controls.Add(this.mail);
            this.panel1.Controls.Add(this.s_age);
            this.panel1.Controls.Add(this.sid);
            this.panel1.Controls.Add(this.s_name);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.withdraw);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.w_id);
            this.panel1.Controls.Add(this.w_det);
            this.panel1.Controls.Add(this.re_wam);
            this.panel1.Controls.Add(this.w_am);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.deposit);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.d_det);
            this.panel1.Controls.Add(this.re_am);
            this.panel1.Controls.Add(this.d_am);
            this.panel1.Controls.Add(this.d_id);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Name = "panel1";
            // 
            // dept
            // 
            resources.ApplyResources(this.dept, "dept");
            this.dept.FormattingEnabled = true;
            this.dept.Items.AddRange(new object[] {
            resources.GetString("dept.Items"),
            resources.GetString("dept.Items1"),
            resources.GetString("dept.Items2"),
            resources.GetString("dept.Items3"),
            resources.GetString("dept.Items4"),
            resources.GetString("dept.Items5")});
            this.dept.Name = "dept";
            this.dept.SelectedIndexChanged += new System.EventHandler(this.s_dept_SelectedIndexChanged);
            // 
            // w_date
            // 
            resources.ApplyResources(this.w_date, "w_date");
            this.w_date.Name = "w_date";
            // 
            // d_date
            // 
            resources.ApplyResources(this.d_date, "d_date");
            this.d_date.Name = "d_date";
            // 
            // b_gr
            // 
            resources.ApplyResources(this.b_gr, "b_gr");
            this.b_gr.FormattingEnabled = true;
            this.b_gr.Items.AddRange(new object[] {
            resources.GetString("b_gr.Items"),
            resources.GetString("b_gr.Items1"),
            resources.GetString("b_gr.Items2"),
            resources.GetString("b_gr.Items3"),
            resources.GetString("b_gr.Items4"),
            resources.GetString("b_gr.Items5"),
            resources.GetString("b_gr.Items6"),
            resources.GetString("b_gr.Items7")});
            this.b_gr.Name = "b_gr";
            // 
            // invalid_members
            // 
            resources.ApplyResources(this.invalid_members, "invalid_members");
            this.invalid_members.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.invalid_members.Name = "invalid_members";
            this.invalid_members.UseVisualStyleBackColor = false;
            this.invalid_members.Click += new System.EventHandler(this.invalid_members_Click);
            // 
            // Add_member
            // 
            resources.ApplyResources(this.Add_member, "Add_member");
            this.Add_member.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.Add_member.Name = "Add_member";
            this.Add_member.UseVisualStyleBackColor = false;
            this.Add_member.Click += new System.EventHandler(this.Add_member_Click);
            // 
            // label25
            // 
            resources.ApplyResources(this.label25, "label25");
            this.label25.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.label25.Name = "label25";
            // 
            // member_add
            // 
            resources.ApplyResources(this.member_add, "member_add");
            this.member_add.Name = "member_add";
            // 
            // label21
            // 
            resources.ApplyResources(this.label21, "label21");
            this.label21.Name = "label21";
            // 
            // requests
            // 
            resources.ApplyResources(this.requests, "requests");
            this.requests.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.requests.Name = "requests";
            this.requests.UseVisualStyleBackColor = false;
            this.requests.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // label24
            // 
            resources.ApplyResources(this.label24, "label24");
            this.label24.Name = "label24";
            // 
            // blood_donor
            // 
            resources.ApplyResources(this.blood_donor, "blood_donor");
            this.blood_donor.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.blood_donor.Name = "blood_donor";
            this.blood_donor.UseVisualStyleBackColor = false;
            this.blood_donor.Click += new System.EventHandler(this.blood_donor_Click);
            // 
            // member_details
            // 
            resources.ApplyResources(this.member_details, "member_details");
            this.member_details.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.member_details.Name = "member_details";
            this.member_details.UseCompatibleTextRendering = true;
            this.member_details.UseVisualStyleBackColor = false;
            this.member_details.Click += new System.EventHandler(this.member_details_Click);
            // 
            // expense_details
            // 
            resources.ApplyResources(this.expense_details, "expense_details");
            this.expense_details.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.expense_details.Name = "expense_details";
            this.expense_details.UseVisualStyleBackColor = false;
            this.expense_details.Click += new System.EventHandler(this.expense_details_Click);
            // 
            // deposit_details
            // 
            resources.ApplyResources(this.deposit_details, "deposit_details");
            this.deposit_details.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.deposit_details.Name = "deposit_details";
            this.deposit_details.UseVisualStyleBackColor = false;
            this.deposit_details.Click += new System.EventHandler(this.deposit_details_Click);
            // 
            // button7
            // 
            resources.ApplyResources(this.button7, "button7");
            this.button7.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.button7.Name = "button7";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // remove
            // 
            resources.ApplyResources(this.remove, "remove");
            this.remove.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.remove.Name = "remove";
            this.remove.UseVisualStyleBackColor = false;
            this.remove.Click += new System.EventHandler(this.remove_Click);
            // 
            // label23
            // 
            resources.ApplyResources(this.label23, "label23");
            this.label23.Name = "label23";
            // 
            // rmember_id
            // 
            resources.ApplyResources(this.rmember_id, "rmember_id");
            this.rmember_id.Name = "rmember_id";
            // 
            // label22
            // 
            resources.ApplyResources(this.label22, "label22");
            this.label22.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.label22.Name = "label22";
            // 
            // update
            // 
            resources.ApplyResources(this.update, "update");
            this.update.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.update.Name = "update";
            this.update.UseVisualStyleBackColor = false;
            this.update.Click += new System.EventHandler(this.update_Click);
            // 
            // label20
            // 
            resources.ApplyResources(this.label20, "label20");
            this.label20.Name = "label20";
            // 
            // label19
            // 
            resources.ApplyResources(this.label19, "label19");
            this.label19.Name = "label19";
            // 
            // label18
            // 
            resources.ApplyResources(this.label18, "label18");
            this.label18.Name = "label18";
            // 
            // label17
            // 
            resources.ApplyResources(this.label17, "label17");
            this.label17.Name = "label17";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // label16
            // 
            resources.ApplyResources(this.label16, "label16");
            this.label16.Name = "label16";
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.Name = "label15";
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.Name = "label14";
            // 
            // p_numb
            // 
            resources.ApplyResources(this.p_numb, "p_numb");
            this.p_numb.Name = "p_numb";
            // 
            // mail
            // 
            resources.ApplyResources(this.mail, "mail");
            this.mail.Name = "mail";
            // 
            // s_age
            // 
            resources.ApplyResources(this.s_age, "s_age");
            this.s_age.Name = "s_age";
            // 
            // sid
            // 
            resources.ApplyResources(this.sid, "sid");
            this.sid.Name = "sid";
            // 
            // s_name
            // 
            resources.ApplyResources(this.s_name, "s_name");
            this.s_name.Name = "s_name";
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.label13.Name = "label13";
            // 
            // withdraw
            // 
            resources.ApplyResources(this.withdraw, "withdraw");
            this.withdraw.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.withdraw.Name = "withdraw";
            this.withdraw.UseVisualStyleBackColor = false;
            this.withdraw.Click += new System.EventHandler(this.withdraw_Click);
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.Name = "label12";
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.Name = "label11";
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.Name = "label10";
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.Name = "label9";
            // 
            // w_id
            // 
            resources.ApplyResources(this.w_id, "w_id");
            this.w_id.Name = "w_id";
            // 
            // w_det
            // 
            resources.ApplyResources(this.w_det, "w_det");
            this.w_det.Name = "w_det";
            // 
            // re_wam
            // 
            resources.ApplyResources(this.re_wam, "re_wam");
            this.re_wam.Name = "re_wam";
            // 
            // w_am
            // 
            resources.ApplyResources(this.w_am, "w_am");
            this.w_am.Name = "w_am";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.label8.Name = "label8";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.label7.Name = "label7";
            // 
            // deposit
            // 
            resources.ApplyResources(this.deposit, "deposit");
            this.deposit.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.deposit.Name = "deposit";
            this.deposit.UseVisualStyleBackColor = false;
            this.deposit.Click += new System.EventHandler(this.button1_Click);
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // d_det
            // 
            resources.ApplyResources(this.d_det, "d_det");
            this.d_det.Name = "d_det";
            // 
            // re_am
            // 
            resources.ApplyResources(this.re_am, "re_am");
            this.re_am.Name = "re_am";
            // 
            // d_am
            // 
            resources.ApplyResources(this.d_am, "d_am");
            this.d_am.Name = "d_am";
            // 
            // d_id
            // 
            resources.ApplyResources(this.d_id, "d_id");
            this.d_id.Name = "d_id";
            this.d_id.TextChanged += new System.EventHandler(this.d_id_TextChanged);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.label1.Name = "label1";
            // 
            // Admin
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Name = "Admin";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Admin_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button deposit;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox d_det;
        private System.Windows.Forms.TextBox re_am;
        private System.Windows.Forms.TextBox d_am;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox w_id;
        private System.Windows.Forms.TextBox w_det;
        private System.Windows.Forms.TextBox re_wam;
        private System.Windows.Forms.TextBox w_am;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button withdraw;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox p_numb;
        private System.Windows.Forms.TextBox mail;
        private System.Windows.Forms.TextBox s_age;
        private System.Windows.Forms.TextBox sid;
        private System.Windows.Forms.TextBox s_name;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button blood_donor;
        private System.Windows.Forms.Button member_details;
        private System.Windows.Forms.Button expense_details;
        private System.Windows.Forms.Button deposit_details;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button remove;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox rmember_id;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button update;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button requests;
        private System.Windows.Forms.Button Add_member;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox member_add;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button invalid_members;
        private System.Windows.Forms.ComboBox b_gr;
        private System.Windows.Forms.DateTimePicker w_date;
        private System.Windows.Forms.DateTimePicker d_date;
        private System.Windows.Forms.ComboBox dept;
        private System.Windows.Forms.TextBox d_id;
    }
}